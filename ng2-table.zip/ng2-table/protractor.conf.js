'use strict';

const config = require('./.ng2-config');

module.exports.config = require('ng2-webpack-config').protractor(config);
