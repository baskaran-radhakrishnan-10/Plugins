import { Component, OnInit, ElementRef } from '@angular/core';
import { ROUTES } from '../left-sidebar/left-sidebar.component';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
    private listTitles: any[];
    location: Location;
    private toggleButton: any;
    private sidebarVisible: boolean;

    constructor(location: Location,  private element: ElementRef) {
        this.location = location;
        this.sidebarVisible = false;
    }

    ngOnInit(){}

}
