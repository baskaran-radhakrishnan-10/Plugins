$(document).ready(function(){
	
	var data={};
	
	$.ajax({
		type : "POST",
		contentType : "application/json",
		accept: 'text/plain',
		url : '/getAllStudents',
		data : JSON.stringify(data),
		dataType: 'text',
		success : function(result) {
			var result = JSON.parse(result);
			console.log(result);
			
			$('#manageStudentTable tbody').html("");
			
			var studentList = result;
			
			var trList = [];
			
			$(studentList).each(function(index,item){
				
				var classType = ''; 
				
				if(index/2 == 1){
					classType = 'odd';
				}else{
					classType = 'even';
				}
				
				var tr = '<tr role="row" class="'+classType+'">'
						+'<td>'+(index+1)+'</td>'
						+'<td>'+item["id"]+'</td>'
						+'<td class="sorting_1">'+item["name"]+'</td>'
						+'<td>'+item["collegeName"]+'</td>'
						+'<td>'+item["course"]+'</td>'
						+'<td>'+item["dept"]+'</td>'
						+'<td>'+item["year"]+'</td>'
						+'<td>'+item["semester"]+'</td>'
						+'<td>'+item["aggregate"]+'</td>'
						+'</tr>';
				
				trList.push(tr);
				
				console.log(index);
				
				console.log(item);
				
				
				
			});
			
			$('#manageStudentTable tbody').html(trList);
			
		},
		error : function(e) {
			console.log("ERROR: ", e);
		}
	});
	
	$('#manageStudentTable').DataTable({
			"ajax" : "data/objects.txt",
			"columns": [
	            { "data": "name" },
	            { "data": "position" },
	            { "data": "office" },
	            { "data": "extn" },
	            { "data": "start_date" },
	            { "data": "salary" }
	        ]
	});
	
});