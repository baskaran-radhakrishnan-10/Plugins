$(document).ready(function(){
	
	var data={};
	
	$.ajax({
		type : "POST",
		contentType : "application/json",
		accept: 'text/plain',
		url : '/getAllStudents',
		data : JSON.stringify(data),
		dataType: 'text',
		success : function(result) {
			var result = JSON.parse(result);
			console.log(result);
		},
		error : function(e) {
			console.log("ERROR: ", e);
		}
	});
	
});