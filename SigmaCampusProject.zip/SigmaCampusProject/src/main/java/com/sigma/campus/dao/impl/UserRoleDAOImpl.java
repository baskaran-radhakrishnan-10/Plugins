package com.sigma.campus.dao.impl;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Repository;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.UserRoleDAOApi;
import com.sigma.campus.entity.UserRole;

@Repository(SpringConstants.USER_ROLE_DAO_API)
public class UserRoleDAOImpl implements UserRoleDAOApi{
	
	private static final Logger LOG = Logger.getLogger(UserRoleDAOImpl.class.getName());

	DatastoreService datastore;

	public UserRoleDAOImpl(){
		datastore = DatastoreServiceFactory.getDatastoreService();
	}

	public UserRole findByUserId(String userId){
		Filter propertyFilter = new FilterPredicate(UserRole.USER_ID, FilterOperator.EQUAL, userId);
		Query query = new Query(UserRole.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		if(null != results && !results.isEmpty()){
			Entity entity=results.get(0);
			UserRole userRole=getModelFromEntity(entity);
			return userRole;
		}
		return null;
	}
	
	public UserRole findByRoleName(String roleName){
		Filter propertyFilter = new FilterPredicate(UserRole.ROLE_NAME, FilterOperator.EQUAL, roleName);
		Query query = new Query(UserRole.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		if(null != results && !results.isEmpty()){
			Entity entity=results.get(0);
			UserRole userRole=getModelFromEntity(entity);
			return userRole;
		}
		return null;
	}
	
	public void saveUserRole(List<UserRole> roleList){
		if(!roleList.isEmpty()){
			for(UserRole role : roleList){
				datastore.put(getEntityFromModel(role));
			}
		}
	}

	public UserRole saveUserRole(UserRole userRole){
		Key key= datastore.put(getEntityFromModel(userRole));
		if(null != key){
			userRole.setKey(key);
			return userRole;
		}
		return null;
	}
	
	private Entity getEntityFromModel(UserRole userRole){
		Entity entity = new Entity(UserRole.ENTITY_NAME,userRole.getRoleName()+"-"+userRole.getUserId());
		entity.setProperty(UserRole.ROLE_NAME,userRole.getRoleName());
		entity.setProperty(UserRole.USER_ID,userRole.getUserId());
		return entity;
	}
	
	private UserRole getModelFromEntity(Entity entity){
		UserRole userRole=new UserRole();
		userRole.setKey(entity.getKey());
		userRole.setUserId((String) entity.getProperty(UserRole.USER_ID));
		userRole.setRoleName((String) entity.getProperty(UserRole.ROLE_NAME));
		return userRole;
	}

}
