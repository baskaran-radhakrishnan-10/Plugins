package com.sigma.campus.service.api;

import com.sigma.campus.entity.User;
import com.sigma.campus.model.UserProfile;

public interface UserLoginServiceAPI {
	
	public boolean isUserAvailable(User User);
	
	public boolean validateLogin(String emailId,String password);

	public User findUserByEmailId(String emailId);

	public User findUserByUserId(String userId);

	public boolean isUserFirstTimeLoggedIn(String emailId);

	public User saveUserProfile(UserProfile profile);

}
