package com.sigma.campus.dao.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.stereotype.Repository;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.CompositeFilter;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.UserProfileDAOApi;
import com.sigma.campus.entity.User;

@Repository(SpringConstants.USER_PROFILE_DAO_API)
public class UserProfileDAOImpl implements UserProfileDAOApi{
	
	private static final Logger LOG = Logger.getLogger(UserProfileDAOImpl.class.getName());

	DatastoreService datastore;

	public UserProfileDAOImpl(){
		datastore = DatastoreServiceFactory.getDatastoreService();
	}

	public boolean isUserAvailable(User User){
		Entity entity = null;
		try {
			entity = datastore.get(User.getKey());
		} catch (EntityNotFoundException e) {
			e.printStackTrace();
		}
		if(null != entity){
			return true;
		}
		return false;
	}
	
	

	public User findUserByEmailId(String emailId){
		Filter propertyFilter = new FilterPredicate(User.EMAIL_ID, FilterOperator.EQUAL, emailId);
		Query query = new Query(User.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		Entity entity=results.get(0);
		User user=getModelFromEntity(entity);
		return user;
	}
	
	public boolean validateLogin(String userId,String password){
		LOG.log(Level.INFO, "<!-----INSIDE validateLogin() METHOD!!!!");
		LOG.log(Level.INFO, "User ID : {0}", userId);
		LOG.log(Level.INFO, "Password : {0}", password);
		Filter userIdFilter = new FilterPredicate(User.USER_ID, FilterOperator.EQUAL, userId);
	    Filter passwordFilter = new FilterPredicate(User.PASSWORD, FilterOperator.EQUAL, password);
	    CompositeFilter filter = CompositeFilterOperator.and(userIdFilter, passwordFilter);
		Query query = new Query(User.ENTITY_NAME).setFilter(filter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		if(null != results && !results.isEmpty()){
			return true;
		}
		return false;
	}

	public User findUserByUserId(String userId){
		Filter propertyFilter = new FilterPredicate(User.USER_ID, FilterOperator.EQUAL, userId);
		Query query = new Query(User.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		if(null != results && !results.isEmpty()){
			Entity entity=results.get(0);
			User user=getModelFromEntity(entity);
			return user;
		}
		return null;
	}

	public boolean isUserFirstTimeLoggedIn(String emailId){
		return false;
	}

	public User saveUserProfile(User User){
		Key key= datastore.put(getEntityFromModel(User));
		if(null != key){
			User.setKey(key);
			return User;
		}
		return null;
	}
	
	private Entity getEntityFromModel(User user){
		Entity entity = new Entity(User.ENTITY_NAME,user.getEmailId());
		entity.setProperty(User.USER_ID,user.getUserId());
		entity.setProperty(User.DELETED,user.isDeleted());
		entity.setProperty(User.EMAIL_ID,user.getEmailId());
		entity.setProperty(User.FIRST_NAME,user.getFirstName());
		entity.setProperty(User.LAST_NAME, user.getLastName());
		entity.setProperty(User.PASSWORD, user.getPassword());
		entity.setProperty(User.FIRST_TIME_LOGIN, user.isFirstTimeLogin());
		return entity;
	}
	
	private User getModelFromEntity(Entity entity){
		User user=new User();
		user.setDeleted((boolean) entity.getProperty(User.DELETED));
		user.setEmailId((String) entity.getProperty(User.EMAIL_ID));
		user.setFirstName((String) entity.getProperty(User.FIRST_NAME));
		user.setFirstTimeLogin((boolean) entity.getProperty(User.FIRST_TIME_LOGIN));
		user.setPassword((String) entity.getProperty(User.PASSWORD));
		user.setLastName((String) entity.getProperty(User.LAST_NAME));
		user.setUserId((String) entity.getProperty(User.USER_ID));
		return user;
	}

}
