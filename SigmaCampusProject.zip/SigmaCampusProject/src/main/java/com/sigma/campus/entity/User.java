package com.sigma.campus.entity;

import java.io.Serializable;

import com.google.appengine.api.datastore.Key;

public class User implements Serializable{

	private static final long serialVersionUID = 4610205203040564709L;

	public static final String FIRST_NAME="firstName";

	public static final String LAST_NAME="lasName";

	public static final String USER_ID="userId";

	public static final String EMAIL_ID="emailId";

	public static final String PASSWORD="password";

	public static final String FIRST_TIME_LOGIN = "firstTimeLogin";

	public static final String DELETED = "deleted";
	
	public static final String ENTITY_NAME="User";
	
	private String firstName;

	private String lastName;

	private String userId;

	private String emailId;

	private String password;

	private boolean firstTimeLogin;

	private boolean deleted;
	
	private Key key;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isFirstTimeLogin() {
		return firstTimeLogin;
	}

	public void setFirstTimeLogin(boolean firstTimeLogin) {
		this.firstTimeLogin = firstTimeLogin;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

}
