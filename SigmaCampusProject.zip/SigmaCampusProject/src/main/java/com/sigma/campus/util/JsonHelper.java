package com.sigma.campus.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sigma.campus.entity.Resources;
import com.sigma.campus.entity.Role;

public class JsonHelper {
	
	public static List<Role> getRoleObjectFromJsonFile(TypeReference<List<Role>> mapType,String filePath){
		List<Role> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return returnObject;
	}
	
	public static List<Resources> getResourceObjectFromJsonFile(TypeReference<List<Resources>> mapType,String filePath){
		List<Resources> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return returnObject;
	}

}
