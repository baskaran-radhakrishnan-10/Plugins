package com.sigma.campus.spring.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sigma.campus.constants.ApplicationConstants;
import com.sigma.campus.entity.Student;
import com.sigma.campus.model.LoginForm;
import com.sigma.campus.service.api.StudentServiceAPI;
import com.sigma.campus.service.api.UserLoginServiceAPI;

@RestController
public class ApplicationRestController {
	
	@Autowired
	private UserLoginServiceAPI userLoginService;
	
	@Autowired
	private StudentServiceAPI studentService;
	
	@PostMapping(value = "/doLogin")
	public ResponseEntity<LoginForm> createCustomer(@RequestBody LoginForm loginForm) {
		
		String userId = loginForm.getUserId();
		String password = loginForm.getPassword();
		
		if(null == userId || userId.isEmpty()){
			loginForm.setErrorOccured(true);
			loginForm.setMessage("Enter valid user id");
			loginForm.setNavigationUrl(ApplicationConstants.LOGIN_PAGE);
		}

		if(null == password || password.isEmpty()){
			loginForm.setErrorOccured(true);
			loginForm.setMessage("Enter valid password");
			loginForm.setNavigationUrl(ApplicationConstants.LOGIN_PAGE);
		}
		
		try {
			loginForm=userLoginService.doLogin(loginForm);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<LoginForm>(loginForm, HttpStatus.OK);
	}
	
	@PostMapping(value="/getAllStudents")
	public ResponseEntity<List<Student>> getAllStudents(@RequestBody Map<String,Object> data) {
		return new ResponseEntity<List<Student>>(studentService.getAllStudents(), HttpStatus.OK);
	}
	
	@PostMapping(value="/createCandidate")
	public ResponseEntity<Boolean> createCandidate(@RequestBody Map<String,String> data) {
		return new ResponseEntity<Boolean>(studentService.equals(data), HttpStatus.OK);
	}

}
