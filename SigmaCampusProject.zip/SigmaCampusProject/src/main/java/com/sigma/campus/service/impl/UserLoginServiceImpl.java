package com.sigma.campus.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.sigma.campus.dao.api.ResourcesDAOApi;
import com.sigma.campus.dao.api.RoleDAOApi;
import com.sigma.campus.dao.api.UserProfileDAOApi;
import com.sigma.campus.entity.Resources;
import com.sigma.campus.entity.Role;
import com.sigma.campus.entity.User;
import com.sigma.campus.model.UserProfile;
import com.sigma.campus.service.api.UserLoginServiceAPI;
import com.sigma.campus.util.JsonHelper;


@Component("userLoginService")
public class UserLoginServiceImpl implements UserLoginServiceAPI{
	
	private static final Logger LOG = Logger.getLogger(UserLoginServiceImpl.class.getName());
	
	@Autowired
	private UserProfileDAOApi userProfileDAOApi;
	
	@Autowired
	private RoleDAOApi roleDAOApi;
	
	@Autowired
	private ResourcesDAOApi resourcesDAOApi;
	
	public UserLoginServiceImpl() {
		
	}
	
	@PostConstruct
	public void init(){
		List<Role> roleList = (List<Role>) JsonHelper.getRoleObjectFromJsonFile(new TypeReference<List<Role>>() {}, "/json/Role.json");
		List<Resources> resourceList = (List<Resources>) JsonHelper.getResourceObjectFromJsonFile(new TypeReference<List<Resources>>() {}, "/json/Resources.json");
		roleDAOApi.saveRole(roleList);
		resourcesDAOApi.saveResource(resourceList);
	}
	
	public boolean isUserAvailable(User userEntity){
		LOG.log(Level.INFO, "<!-----INSIDE isUserAvailable() METHOD!!!!");
		return userProfileDAOApi.isUserAvailable(userEntity);
	}
	
	public boolean validateLogin(String emailId,String password){
		LOG.log(Level.INFO, "<!-----INSIDE validateLogin() METHOD!!!!");
		return userProfileDAOApi.validateLogin(emailId, password);
	}

	public User findUserByEmailId(String emailId){
		LOG.log(Level.INFO, "<!-----INSIDE findUserByEmailId() METHOD!!!!");
		return userProfileDAOApi.findUserByEmailId(emailId);
	}

	public User findUserByUserId(String userId){
		LOG.log(Level.INFO, "<!-----INSIDE findUserByUserId() METHOD!!!!");
		return userProfileDAOApi.findUserByUserId(userId);
	}

	public boolean isUserFirstTimeLoggedIn(String emailId){
		LOG.log(Level.INFO, "<!-----INSIDE isUserFirstTimeLoggedIn() METHOD!!!!");
		return userProfileDAOApi.isUserFirstTimeLoggedIn(emailId);
	}

	public User saveUserProfile(UserProfile profile){
		LOG.log(Level.INFO, "<!-----INSIDE saveUserProfile() METHOD!!!!");
		User entity = new User();
		entity.setUserId(profile.getUserId());
		entity.setDeleted(false);
		entity.setEmailId(profile.getEmail());
		entity.setFirstName(profile.getFirstName());
		entity.setFirstTimeLogin(true);
		entity.setLastName(profile.getLastName());
		entity.setPassword(profile.getPassword());
		return userProfileDAOApi.saveUserProfile(entity);
	}
	
	/*public Role saveRoleInfo(){
		
	}*/
	
	

}
