package com.sigma.campus.dao.api;

import java.util.List;

import com.sigma.campus.entity.User;

public interface UserProfileDAOApi {
	
	public boolean isUserAvailable(User User);
	
	public User validateLogin(String emailId,String password);

	public User findUserByEmailId(String emailId);

	public User findUserByUserId(String userId);

	public boolean isUserFirstTimeLoggedIn(String emailId);

	public User saveUserProfile(User User);
	
	public void saveUserProfile(List<User> userList);

}
