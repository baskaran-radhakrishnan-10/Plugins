package com.sigma.campus.entity;

import com.google.appengine.api.datastore.Key;

public class UserRole {
	
	public static final String USER_ID="userId";
	
	public static final String ROLE_NAME="roleName";
	
	public static final String ENTITY_NAME="UserRole";
	
	private String userId;
	
	private String roleName;
	
	private Key key;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

}
