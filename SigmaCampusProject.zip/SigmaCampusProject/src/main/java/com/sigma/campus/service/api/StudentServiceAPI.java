package com.sigma.campus.service.api;

import java.util.List;

import com.sigma.campus.entity.Student;

public interface StudentServiceAPI {
	
	public List<Student> getAllStudents();

}
