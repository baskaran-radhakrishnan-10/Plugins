package com.sigma.campus.service.api;

import java.util.List;
import java.util.Map;

import com.sigma.campus.entity.Student;

public interface StudentServiceAPI {
	
	public List<Student> getAllStudents();
	
	public boolean  saveCandidate(Map<String,String> requestObject);
	
	public Map<String,Object> getProfileInfo(String userName);

}
