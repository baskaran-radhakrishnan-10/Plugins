package com.sigma.campus.dao.api;

import java.util.List;

import com.sigma.campus.entity.Student;

public interface StudentDAOApi {
	
	public List<Student> getAllStudents();
	
	public Student findStudentById(String id);
	
	public Student findStudentByCollegeName(String collegeName);
	
	public Student saveStudent(Student student);
	
	public void saveStudentProfile(List<Student> studentList);

}
