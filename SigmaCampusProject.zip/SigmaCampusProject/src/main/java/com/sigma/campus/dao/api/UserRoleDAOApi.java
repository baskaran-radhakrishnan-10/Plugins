package com.sigma.campus.dao.api;

import java.util.List;

import com.sigma.campus.entity.UserRole;

public interface UserRoleDAOApi {
	
	public UserRole findByUserId(String userId);
	
	public UserRole findByRoleName(String roleName);
	
	public UserRole saveUserRole(UserRole role);
	
	public void saveUserRole(List<UserRole> role);
	
}
