package com.sigma.campus.constants;

public class SpringConstants {
	
	public static final String USER_PROFILE_DAO_API = "userProfileDAOApi";
	
	public static final String ROLE_DAO_API = "roleDAOApi";
	
	public static final String RESOURCES_DAO_API = "resourcesDAOApi";

}
