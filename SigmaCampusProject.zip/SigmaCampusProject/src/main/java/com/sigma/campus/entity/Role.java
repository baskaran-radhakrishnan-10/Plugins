package com.sigma.campus.entity;

import java.util.List;

import com.google.appengine.api.datastore.Key;

public class Role {
	
	public static final String ROLE_NAME="roleName";

	public static final String ROLE_DESC="roleDesc";
	
	public static final String RESOURCE_LIST="resourceList";
	
	public static final String ENTITY_NAME="Role";
	
	private String roleName;
	
	private String roleDesc;
	
	private Key key;
	
	/*private List<Resources> resourceList;*/

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

	/*public List<Resources> getResourceList() {
		return resourceList;
	}

	public void setResourceList(List<Resources> resourceList) {
		this.resourceList = resourceList;
	}*/

}
