package com.sigma.campus.spring.controller;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.cache.CacheException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sigma.campus.constants.ApplicationConstants;

@Controller
public class WebsiteMainController {
	
	private static final Logger LOG = Logger.getLogger(WebsiteMainController.class.getName());
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String rootUrl(HttpServletRequest request,HttpServletResponse response){
		LOG.log(Level.INFO, "Inside Root URL Mapper");
		return ApplicationConstants.REDIRECT_HOME_PAGE;
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String showDashboardPage(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.HOME_PAGE;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.LOGIN_PAGE;
	}
	
	@RequestMapping(value = "/signout")
	public String doLogout(HttpServletRequest request) throws CacheException{
		request.getSession().invalidate();
		return ApplicationConstants.REDIRECT_LOGIN_PAGE;
	}
	
	@RequestMapping(value = "/profile")
	public String showProfilePage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.PROFILE;
	}
	
	@RequestMapping(value = "/manage")
	public String decideMangePage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.PROFILE;
	}
	
	@RequestMapping(value = "/manageStudents")
	public String showManageStudentsPage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.MANAGE_STUDENTS;
	}
	
	@RequestMapping(value = "/manageColleges")
	public String showManageCollegesPage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.MANAGE_COLLEGES;
	}
	
}
