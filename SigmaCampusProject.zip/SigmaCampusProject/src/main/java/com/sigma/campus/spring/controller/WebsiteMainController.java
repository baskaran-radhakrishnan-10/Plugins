package com.sigma.campus.spring.controller;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.cache.CacheException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sigma.campus.constants.ApplicationConstants;
import com.sigma.campus.model.LoginModelAttribute;
import com.sigma.campus.service.api.UserLoginServiceAPI;

@Controller
public class WebsiteMainController {
	
	private static final Logger LOG = Logger.getLogger(WebsiteMainController.class.getName());
	
	@Autowired
	private UserLoginServiceAPI userLoginService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String rootUrl(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.REDIRECT_HOME_PAGE;
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String showDashboardPage(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.HOME_PAGE;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.LOGIN_PAGE;
	}
	
	@RequestMapping(value="/doLogin", method=RequestMethod.POST)
	public String doLoginPost(HttpServletRequest request,@ModelAttribute("loginModelAttribute")@Valid LoginModelAttribute loginModelAttribute,BindingResult result ,Model model) {
		if (result.hasErrors()) {
			return ApplicationConstants.LOGIN_PAGE;
		}
		//loginModelAttribute.setModel(model);
		
		model=loginModelAttribute.getModel();
		
		String userId=loginModelAttribute.getUserId().trim();

		String passwordText=loginModelAttribute.getPassword().trim();

		if(null == userId || userId.isEmpty()){
			model.addAttribute("error", "Enter valid user id");
			return ApplicationConstants.LOGIN_PAGE;
		}

		if(null == passwordText || passwordText.isEmpty()){
			model.addAttribute("error", "Enter valid password");
			return ApplicationConstants.LOGIN_PAGE;
		}
		
		try {
			loginModelAttribute=userLoginService.doLogin(loginModelAttribute);;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(!loginModelAttribute.isSuccess()){
			return loginModelAttribute.getResultMapping();
		}
		
		LOG.log(Level.INFO,"<----- END doLogin Method ----->");
		
		return ApplicationConstants.REDIRECT_HOME_PAGE;
		
	}
	
	@RequestMapping(value = "/logout")
	public String doLogout() throws CacheException{
		//loginController.doLogout();
		return ApplicationConstants.REDIRECT_LOGIN_PAGE;
	}
	
	
}
