package com.sigma.campus.dao.impl;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Repository;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.ResourcesDAOApi;
import com.sigma.campus.entity.Resources;
import com.sigma.campus.entity.Role;

@Repository(SpringConstants.RESOURCES_DAO_API)
public class ResourcesDAOImpl implements ResourcesDAOApi{
	
	private static final Logger LOG = Logger.getLogger(ResourcesDAOImpl.class.getName());

	DatastoreService datastore;

	public ResourcesDAOImpl(){
		datastore = DatastoreServiceFactory.getDatastoreService();
	}

	public Resources findResourceByResourceID(String resourceId){
		Filter propertyFilter = new FilterPredicate(Resources.RESOURCE_ID, FilterOperator.EQUAL, resourceId);
		Query query = new Query(Resources.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		if(null != results && !results.isEmpty()){
			Entity entity=results.get(0);
			Resources resource=getModelFromEntity(entity);
			return resource;
		}
		return null;
	}
	
	public void saveResource(List<Resources> resourcesList){
		if(!resourcesList.isEmpty()){
			for(Resources resource : resourcesList){
				datastore.put(getEntityFromModel(resource));
			}
		}
	}

	public Resources saveResource(Resources resource){
		Key key= datastore.put(getEntityFromModel(resource));
		if(null != key){
			resource.setKey(key);
			return resource;
		}
		return null;
	}
	
	private Entity getEntityFromModel(Resources resource){
		Entity entity = new Entity(Resources.ENTITY_NAME,resource.getResourceId());
		entity.setProperty(Resources.RESOURCE_NAME,resource.getResourceName());
		entity.setProperty(Resources.RESOURCE_MENU_TYPE,resource.getResourceMenuType());
		entity.setProperty(Resources.RESOURCE_ID,resource.getResourceId());
		return entity;
	}
	
	@SuppressWarnings("unchecked")
	private Resources getModelFromEntity(Entity entity){
		Resources resource=new Resources();
		resource.setKey(entity.getKey());
		resource.setResourceId((String) entity.getProperty(Resources.RESOURCE_ID));
		resource.setResourceName((String) entity.getProperty(Resources.RESOURCE_NAME));
		resource.setResourceMenuType((String) entity.getProperty(Resources.RESOURCE_MENU_TYPE));
		return resource;
	}

}
