package com.sigma.campus.service.impl;

import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.StudentDAOApi;
import com.sigma.campus.dao.api.UserRoleDAOApi;
import com.sigma.campus.entity.Student;
import com.sigma.campus.entity.UserRole;
import com.sigma.campus.model.UserProfile;
import com.sigma.campus.service.api.StudentServiceAPI;
import com.sigma.campus.service.api.UserLoginServiceAPI;
import com.sigma.campus.util.JsonHelper;

@Component(SpringConstants.STUDENT_SERVICE)
public class StudentServiceImpl implements StudentServiceAPI{

	private static final Logger LOG = Logger.getLogger(StudentServiceImpl.class.getName());

	@Autowired
	private StudentDAOApi studentDAOApi;
	
	@Autowired
	private UserLoginServiceAPI userLoginService;
	
	@Autowired
	private UserRoleDAOApi userRoleDAOApi;

	@PostConstruct
	public void init(){
		LOG.log(Level.INFO, "Inside");
		List<Student> studentList = (List<Student>) JsonHelper.getStudentObjectFromJsonFile(new TypeReference<List<Student>>() {}, "/json/Students.json");
		studentDAOApi.saveStudentProfile(studentList);
	}
	
	public List<Student> getAllStudents(){
		return studentDAOApi.getAllStudents();
	}
	
	
	public boolean  saveCandidate(Map<String,String> requestObject){
		try{
			UserProfile user = new UserProfile();
			user.setEmail(requestObject.get("EMAIL"));
			user.setFirstName(requestObject.get("FIRST_NAME"));
			user.setLastName(requestObject.get("LAST_NAME"));
			user.setPassword(requestObject.get("PASSWORD"));
			user.setUserId(requestObject.get("USER_ID"));
			user.setConfirmPassword(requestObject.get("PASSWORD"));
			
			UserRole userRole = new UserRole();
			userRole.setRoleName("STUDENT");
			userRole.setUserId(requestObject.get("USER_ID"));
			
			userLoginService.saveUserProfile(user);
			userRoleDAOApi.saveUserRole(userRole);
			
		}catch(Exception e){
			requestObject.put("ERROR", e.getMessage());
			return false;
		}
		
		return true;
	}

}
