package com.sigma.campus.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.StudentDAOApi;
import com.sigma.campus.entity.Student;
import com.sigma.campus.service.api.StudentServiceAPI;
import com.sigma.campus.util.JsonHelper;

@Component(SpringConstants.STUDENT_SERVICE)
public class StudentServiceImpl implements StudentServiceAPI{

	private static final Logger LOG = Logger.getLogger(StudentServiceImpl.class.getName());

	@Autowired
	private StudentDAOApi studentDAOApi;

	@PostConstruct
	public void init(){
		LOG.log(Level.INFO, "Inside");
		List<Student> studentList = (List<Student>) JsonHelper.getStudentObjectFromJsonFile(new TypeReference<List<Student>>() {}, "/json/Students.json");
		studentDAOApi.saveStudentProfile(studentList);
	}
	
	public List<Student> getAllStudents(){
		return studentDAOApi.getAllStudents();
	}
	
	

}
