$(document).ready(function() {
	
	$('#messageLabel').text('');
	
	//Customer-Form submit
	$("#loginForm").submit(function(event) {
		// Prevent the form from submitting via the browser.
		event.preventDefault();
		// get data from submit form
		
		var loginForm = {
			userId : $('#userIdField').val(),
			password : $('#passwordIdField').val()
		}
		
		$.ajax({
			type : "POST",
			contentType : "application/json",
			url : '/doLogin',
			data : JSON.stringify(loginForm),
			success : function(result) {
				console.log(result);
				//var result = JSON.parse(result);
				var errorOccured = result["errorOccured"];
				var navigationUrl = result['navigationUrl'];
				var message = result['message'];
				console.log(errorOccured);
				console.log(navigationUrl);
				console.log(message);
				if(errorOccured){
					$('#messageLabel').text(message);
				}else{
					window.location.href = navigationUrl;
				}
			},
			error : function(e) {
				console.log("ERROR: ", e);
			}
		});
		
	});

});

