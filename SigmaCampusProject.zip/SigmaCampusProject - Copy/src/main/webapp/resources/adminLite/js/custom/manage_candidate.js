$(document).ready(function(){
	
	console.log("manage candidate!!!");
	
	$('#createCandiateButton').click(function(event){
		
		var data = {};
		
		data['EMAIL'] = $('#candidateEmail').val().trim();
		data['USER_NAME'] = $('#candidateUserName').val().trim();
		data['FIRST_NAME'] = $('#candidateFirstName').val().trim();
		data['LAST_NAME'] = $('#candidateLastName').val().trim();
		data['PASSWORD'] = $('#candidatePassword').val().trim();
		
		data['AGGREGATE'] = $('#candidateAggregate').val().trim();
		data['COLLEGE_NAME'] = $('#candidateCollegeName').val().trim();
		data['COURSE'] = $("#candidateCourseName option:selected" ).text();
		data['SEM'] = $('#candidateSemester').val().trim();
		data['DEPT'] = $("#candidateDepartmentName option:selected" ).text();
		data['YEAR'] = $('#candidateYear').val().trim();
		data['REG_NO'] = $('#candidateRegNumber').val().trim();
		
		$.ajax({
			type : "POST",
			contentType : "application/json",
			url : '/createCandidate',
			data : JSON.stringify(data),
			success : function(result) {
				console.log(result);
				$('#successAlertDiv').show();
				$('#successAlertDiv p').text("Candidate Profile Successfully Created.");
			},
			error : function(e) {
				console.log("ERROR: ", e);
			}
		});
		
	});
	
});