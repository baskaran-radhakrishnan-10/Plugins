$(document).ready(function(){
	var data={};
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : '/getProfileDetails',
		data : JSON.stringify(data),
		success : function(result) {
			console.log(result);
			//var result = JSON.parse(result);
			
			var user = result['USER'];
			var candidate = result['CANDIDATE'];
			var role = result['ROLE'];
			
			$('.loggedInUserName').text(user['firstName']+" "+user['lastName']);
			
			$('#roleName').text(role['roleName']);
			
			$('#collegeNameDiv p').text(candidate['collegeName']);
			
			eval($('#collegeNameDiv p').text());
			
			$('#courseNameDiv p').text(candidate['course']);
			
			$('#deptDiv p').text(candidate['dept']);
			
			$('#gradeDiv p').text(candidate['aggregate']);
			
			$('#candidateUserName').val(user['userId']);
			
			$('#candidateFirstName').val(user['firstName']);
			
			$('#candidateLastName').val(user['lastName']);
			
			$('#candidateEmail').val(user['emailId']);
			
		},
		error : function(e) {
			console.log("ERROR: ", e);
		}
	});
});