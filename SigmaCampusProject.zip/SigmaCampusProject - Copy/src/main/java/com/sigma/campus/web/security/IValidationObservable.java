package com.sigma.campus.web.security;

import javax.servlet.http.HttpServletRequest;

public interface IValidationObservable {
	
	public void setRequestForProcessing(HttpServletRequest request);
	
	public boolean isValidationConfiguredForUrl(HttpServletRequest request) throws ValidatorException;
	
	public void setValidationHelper(ValidationHelper validationHelper);
}
