package com.sigma.campus.dao.impl;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Repository;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.RoleDAOApi;
import com.sigma.campus.entity.Resources;
import com.sigma.campus.entity.Role;

@Repository(SpringConstants.ROLE_DAO_API)
public class RoleDAOImpl implements RoleDAOApi{
	
	private static final Logger LOG = Logger.getLogger(RoleDAOImpl.class.getName());

	DatastoreService datastore;

	public RoleDAOImpl(){
		datastore = DatastoreServiceFactory.getDatastoreService();
	}

	public Role findRoleByRoleName(String roleName){
		Filter propertyFilter = new FilterPredicate(Role.ROLE_NAME, FilterOperator.EQUAL, roleName);
		Query query = new Query(Role.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		if(null != results && !results.isEmpty()){
			Entity entity=results.get(0);
			Role role=getModelFromEntity(entity);
			return role;
		}
		return null;
	}
	
	public void saveRole(List<Role> roleList){
		if(!roleList.isEmpty()){
			for(Role role : roleList){
				datastore.put(getEntityFromModel(role));
			}
		}
	}

	public Role saveRole(Role role){
		Key key= datastore.put(getEntityFromModel(role));
		if(null != key){
			role.setKey(key);
			return role;
		}
		return null;
	}
	
	private Entity getEntityFromModel(Role role){
		Entity entity = new Entity(Role.ENTITY_NAME,role.getRoleName());
		entity.setProperty(Role.ROLE_NAME,role.getRoleName());
		entity.setProperty(Role.ROLE_DESC,role.getRoleDesc());
		//entity.setProperty(Role.RESOURCE_LIST,role.getResourceList());
		return entity;
	}
	
	@SuppressWarnings("unchecked")
	private Role getModelFromEntity(Entity entity){
		Role role=new Role();
		role.setKey(entity.getKey());
		//role.setResourceList((List<Resources>) entity.getProperty(Role.RESOURCE_LIST));
		role.setRoleDesc((String) entity.getProperty(Role.ROLE_DESC));
		role.setRoleName((String) entity.getProperty(Role.ROLE_NAME));
		return role;
	}

}
