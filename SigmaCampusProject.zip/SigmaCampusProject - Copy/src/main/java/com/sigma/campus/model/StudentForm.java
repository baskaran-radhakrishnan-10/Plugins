package com.sigma.campus.model;

public class StudentForm {
	
	

}
