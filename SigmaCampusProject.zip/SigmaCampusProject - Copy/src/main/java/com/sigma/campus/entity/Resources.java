package com.sigma.campus.entity;

import java.io.Serializable;

import com.google.appengine.api.datastore.Key;

public class Resources implements Serializable{
	
	private static final long serialVersionUID = -2958563678648012015L;

	public static final String RESOURCE_NAME="resourceName";

	public static final String RESOURCE_MENU_TYPE="resourceMenuType";
	
	public static final String ENTITY_NAME="Resources";
	
	public static final String RESOURCE_ID="resourceId";
	
	private String resourceId;
	
	private String resourceName;
	
	private String resourceMenuType;
	
	private Key key;

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getResourceMenuType() {
		return resourceMenuType;
	}

	public void setResourceMenuType(String resourceMenuType) {
		this.resourceMenuType = resourceMenuType;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	} 

}
