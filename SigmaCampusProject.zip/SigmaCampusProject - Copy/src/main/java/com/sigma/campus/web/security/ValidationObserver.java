package com.sigma.campus.web.security;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("validationObserver")
public class ValidationObserver implements Observer{
	
	private static final Logger LOG = Logger.getLogger(ValidationObserver.class.getName());
	
	/**
	 * This variable holds the observables configured for the instance as a list.
	 */
	private List<BaseValidationObservable> observablesList;
	
	public List<BaseValidationObservable> getObservablesList() {
		return observablesList;
	}

	public void setObservablesList(List<BaseValidationObservable> observablesList) {
		this.observablesList = observablesList;
	}

	/**
	 * This is a helper class to do activities common for all observables.
	 */
	@Autowired
	private ValidationHelper validationHelper;
	
	
	/**
	 * ExecutorService helps in running  the observables in parallel.
	 */
	
	private ExecutorService executorService = null;
	
	/**
	 * This variable is to hold the start time of the check
	 */
	
	private long tStartScan = 0l;
	
	/**
	 * This variable is to hold the security check flag.
	 */
	
	private boolean foundSecurityIssue = false;
	
	
	public boolean isFoundSecurityIssue() {
		return foundSecurityIssue;
	}

	public void setFoundSecurityIssue(boolean foundSecurityIssue) {
		this.foundSecurityIssue = foundSecurityIssue;
	}

	public ValidationObserver() {
		LOG.log(Level.INFO,"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		LOG.log(Level.INFO,"validationHelper :"+validationHelper);
		observablesList = new ArrayList<BaseValidationObservable>();
		
		validationHelper = new ValidationHelper();
		
		if(null != validationHelper) {
			LOG.log(Level.INFO,"^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
			LOG.log(Level.INFO,"Observable Run List :"+validationHelper.getObservablesRunList().toString());
			for(String str:validationHelper.getObservablesRunList()){ 
				if(SecurityConstants.XSS_OBSERVABLE_NAME.equalsIgnoreCase(str)) {
					XSSObservable obj = new XSSObservable();
					observablesList.add(obj);
				}
			}
		}	
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		LOG.log(Level.INFO,"VALIDATIONOBSERVER UPDATE METHOD CALLED....");
		if(arg1 instanceof Boolean) {
			Boolean flag = (Boolean) arg1;
			if(flag) {
				LOG.log(Level.INFO,"SecurityObservable:Issue from..." + arg0.toString());
				long tend = System.nanoTime();
				LOG.log(Level.INFO,"SecurityObservable: SECURITY VULNERABILITY FOUND at.... " + (tend-tStartScan));
				setFoundSecurityIssue(true);
				stopAll();
			}
		}
	}
	
	/**
  	 * This methods creates and starts the threads(observables) based on the security configuration for the request URL
  	 * @author Pradheep B
  	 * @param HttpServletRequest request
  	 *  
  	 */
	public boolean startScan(HttpServletRequest request,Map<String,String> data)
			throws ValidatorException {
		LOG.log(Level.INFO,"INSIDE START SCAN....");
		tStartScan = System.nanoTime();
		try {
	
			String pageURL =  request.getParameter("view");
			
			if (pageURL == null) {
				pageURL = request.getRequestURI();
			}
			
			boolean isAjax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));

			LOG.log(Level.INFO,"ajax :"+isAjax);
			
			long forLoopStart=System.nanoTime();
			Set<Callable<BaseValidationObservable>> callables = new HashSet<Callable<BaseValidationObservable>>();
			for(BaseValidationObservable observable:this.getObservablesList()) {
				observable.setValidationHelper(validationHelper);
				if(observable.isValidationConfiguredForUrl(request)) {
					observable.setRequestForProcessing(request);
					if(isAjax){
						observable.setDataObject(data);
					}
					callables.add((Callable<BaseValidationObservable>) observable);
					observable.addObserver(this);
				}
			}
			long forLoopEnd = System.nanoTime();
			LOG.log(Level.INFO,"SecurityObservable:ForLoopTime taken:" + (forLoopEnd-forLoopStart));
			long esCreationStart = System.nanoTime();
			if(callables.size() > 0) {
				LOG.log(Level.INFO,"SecurityObservable: Callable Size:" +callables.size());
				executorService= Executors.newFixedThreadPool(callables.size());
				executorService.invokeAll(callables);
				LOG.log(Level.INFO,"SecurityObservable: Callable Invoked:" );
				//executorService.shutdownNow();
				//LOG.log(Level.INFO,"SecurityObservable: Shutdwon Invoked:" );
			}
			else {
				LOG.log(Level.INFO,"SecurityObservable: No Observables configured for the url....No Security issue found" + pageURL);
				foundSecurityIssue = false;
			}
			long esCreationEnd = System.nanoTime();
			LOG.log(Level.INFO,"SecurityObservable: Executor creation Time taken:" + (esCreationEnd-esCreationStart));
		} catch (Exception e) {
			LOG.log(Level.SEVERE, e.getMessage());
			//throw new ValidatorException(ValidatorFaultCode.FAIL_VALIDATE,e);	 
		}
		
		request.setAttribute("REQUEST_SEC_VALIDATED","true");
		long tEnd = System.nanoTime();
		LOG.log(Level.INFO,"SecurityObservable: Time Taken Observer to End :" + (tEnd-tStartScan));
		
		if(null!=request.getAttribute("CONCURRENT_LOGIN") && "TRUE".equalsIgnoreCase((String)request.getAttribute("CONCURRENT_LOGIN"))){
			//LOG.error("ValidationObserver:EXCEPTION OCCURED IN CLR",new ValidatorException(ValidatorFaultCode.CONCURRENT_LOGIN_FAILED));
			request.getSession().setAttribute("CLRFound","TRUE");
			//throw new ValidatorException(ValidatorFaultCode.CONCURRENT_LOGIN_FAILED,null);
		}
		
		if(isFoundSecurityIssue()) {
				//throw new ValidatorException(ValidatorFaultCode.FAIL_VALIDATE,null);
		}
		
		return foundSecurityIssue;
	}
	
	/**
	 * This Method stops the running executor service
	 */
	
	public void stopAll() {
		LOG.log(Level.INFO,"SecurityObservable: Stopping all...");
		executorService.shutdownNow();
		LOG.log(Level.INFO,"SecurityObservable: Stopped");
	}

}
