package com.sigma.campus.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.stereotype.Repository;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.StudentDAOApi;
import com.sigma.campus.entity.Student;

@Repository(SpringConstants.STUDENT_DAO_API)
public class StudentDAOImpl implements StudentDAOApi{

	private static final Logger LOG = Logger.getLogger(StudentDAOImpl.class.getName());

	DatastoreService datastore;

	public StudentDAOImpl(){
		datastore = DatastoreServiceFactory.getDatastoreService();
	}
	
	public List<Student> getAllStudents(){
		Query query = new Query(Student.ENTITY_NAME);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		List<Student> studentList=getModelFromEntityList(results);
		return studentList;
	}
	
	public Student findStudentByCollegeName(String collegeName){
		Filter propertyFilter = new FilterPredicate(Student.COLLEGE_NAME, FilterOperator.EQUAL, collegeName);
		Query query = new Query(Student.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		Entity entity=results.get(0);
		Student student=getModelFromEntity(entity);
		return student;
	}

	public Student findStudentById(String id){
		Filter propertyFilter = new FilterPredicate(Student.ID, FilterOperator.EQUAL, id);
		Query query = new Query(Student.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		Entity entity=results.get(0);
		Student student=getModelFromEntity(entity);
		return student;
	}
	
	public Student findStudentByUserName(String userName){
		Filter propertyFilter = new FilterPredicate(Student.NAME, FilterOperator.EQUAL, userName);
		Query query = new Query(Student.ENTITY_NAME).setFilter(propertyFilter);
		List<Entity> results = datastore.prepare(query).asList(FetchOptions.Builder.withDefaults());
		Entity entity=results.get(0);
		Student student=getModelFromEntity(entity);
		return student;
	}

	public Student saveStudent(Student student){
		Key key= datastore.put(getEntityFromModel(student));
		if(null != key){
			student.setKey(key);
			return student;
		}
		return null;
	}

	public void saveStudentProfile(List<Student> studentList){
		if(!studentList.isEmpty()){
			datastore.put(getEntityFromModelList(studentList));
		}
	}

	private List<Entity> getEntityFromModelList(List<Student> studentList){
		List<Entity> entityList = new ArrayList<>();
		for(Student student:studentList){
			entityList.add(getEntityFromModel(student));
		}
		return entityList;
	}
	
	private List<Student> getModelFromEntityList(List<Entity> entityList){
		List<Student> studentList = new ArrayList<>();
		for(Entity entity:entityList){
			studentList.add(getModelFromEntity(entity));
		}
		return studentList;
	}

	private Entity getEntityFromModel(Student student){
		Entity entity = new Entity(Student.ENTITY_NAME,student.getId());
		entity.setProperty(Student.ID,student.getId());
		entity.setProperty(Student.AGGREGATE,student.getAggregate());
		entity.setProperty(Student.COLLEGE_NAME,student.getCollegeName());
		entity.setProperty(Student.COURSE,student.getCourse());
		entity.setProperty(Student.NAME, student.getName());
		entity.setProperty(Student.SEMESTER, student.getSemester());
		entity.setProperty(Student.YEAR, student.getYear());
		entity.setProperty(Student.DEPT, student.getDept());
		return entity;
	}

	private Student getModelFromEntity(Entity entity){
		LOG.log(Level.INFO, "Inside getModelFromEntity", entity);
		Student student=new Student();
		student.setAggregate((double) entity.getProperty(Student.AGGREGATE));
		student.setId((long) entity.getProperty(Student.ID));
		student.setCollegeName((String) entity.getProperty(Student.COLLEGE_NAME));
		student.setCourse((String) entity.getProperty(Student.COURSE));
		student.setName((String) entity.getProperty(Student.NAME));
		student.setSemester((String) entity.getProperty(Student.SEMESTER));
		student.setYear((String) entity.getProperty(Student.YEAR));
		student.setDept((String) entity.getProperty(Student.DEPT));
		return student;
	}

}
