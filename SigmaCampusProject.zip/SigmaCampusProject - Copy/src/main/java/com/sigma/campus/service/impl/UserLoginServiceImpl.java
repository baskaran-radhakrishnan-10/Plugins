package com.sigma.campus.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.events.EventException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.sigma.campus.constants.ApplicationConstants;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.ResourcesDAOApi;
import com.sigma.campus.dao.api.RoleDAOApi;
import com.sigma.campus.dao.api.StudentDAOApi;
import com.sigma.campus.dao.api.UserProfileDAOApi;
import com.sigma.campus.dao.api.UserRoleDAOApi;
import com.sigma.campus.entity.Resources;
import com.sigma.campus.entity.Role;
import com.sigma.campus.entity.Student;
import com.sigma.campus.entity.User;
import com.sigma.campus.entity.UserRole;
import com.sigma.campus.model.LoginForm;
import com.sigma.campus.model.UserProfile;
import com.sigma.campus.service.api.UserLoginServiceAPI;
import com.sigma.campus.util.JsonHelper;


@Component(SpringConstants.USER_LOGIN_SERVICE)
public class UserLoginServiceImpl implements UserLoginServiceAPI{
	
	private static final Logger LOG = Logger.getLogger(UserLoginServiceImpl.class.getName());
	
	@Autowired
	private UserProfileDAOApi userProfileDAOApi;
	
	@Autowired
	private RoleDAOApi roleDAOApi;
	
	@Autowired
	private ResourcesDAOApi resourcesDAOApi;
	
	@Autowired
	private UserRoleDAOApi userRoleDAOApi;
	
	@Autowired
	private StudentDAOApi studentDAOApi;
	
	@Autowired
	private HttpSession session;
	
	@PostConstruct
	public void init(){
		List<User> userList = (List<User>) JsonHelper.getUserObjectFromJsonFile(new TypeReference<List<User>>() {}, "/json/Users.json");
		List<Role> roleList = (List<Role>) JsonHelper.getRoleObjectFromJsonFile(new TypeReference<List<Role>>() {}, "/json/Role.json");
		List<Resources> resourceList = (List<Resources>) JsonHelper.getResourceObjectFromJsonFile(new TypeReference<List<Resources>>() {}, "/json/Resources.json");
		List<UserRole> userRoleList = (List<UserRole>) JsonHelper.getUserRoleObjectFromJsonFile(new TypeReference<List<UserRole>>() {}, "/json/UserRole.json");
		userProfileDAOApi.saveUserProfile(userList);
		roleDAOApi.saveRole(roleList);
		resourcesDAOApi.saveResource(resourceList);
		userRoleDAOApi.saveUserRole(userRoleList);
	}
	
	public boolean isUserAvailable(User userEntity){
		LOG.log(Level.INFO, "<!-----INSIDE isUserAvailable() METHOD!!!!");
		return userProfileDAOApi.isUserAvailable(userEntity);
	}
	
	@Override
	public LoginForm doLogin(LoginForm loginForm){
		
		LOG.log(Level.INFO,"START doLogin Method");
		
		try {
			
			User user=userProfileDAOApi.validateLogin(loginForm.getUserId(), loginForm.getPassword());
			
			if(null == user){
				loginForm.setErrorOccured(true);
				loginForm.setMessage("Invalid user-id or password.");
				loginForm.setNavigationUrl(ApplicationConstants.LOGIN_PAGE);
				return loginForm;
			}
			
			UserRole userRole=userRoleDAOApi.findByUserId(loginForm.getUserId());
			
			if(null == userRole){
				loginForm.setErrorOccured(true);
				loginForm.setMessage("Invalid Role Permission Assigned.");
				loginForm.setNavigationUrl(ApplicationConstants.LOGIN_PAGE);
				return loginForm;
			}
			
			//List<RolesResources> roleResourceList=roleResourceService.getRolesResourcesByRoleId(role.getGkey());

			if(!loginForm.isErrorOccured()){
				
				session.setAttribute(ApplicationConstants.USER_OBJ, user);
				
				session.setAttribute(ApplicationConstants.USER_ID, user.getUserId());
				
				session.setAttribute(ApplicationConstants.USER_NAME, user.getFirstName()+"-"+user.getLastName());
				
				session.setAttribute(ApplicationConstants.IS_LOGGED_IN, true);
				
				session.setAttribute(ApplicationConstants.ROLE_ID, userRole.getRoleName());
				
				session.setAttribute(ApplicationConstants.FIRST_LOGIN, user.isFirstTimeLogin());
				
				if("STUDENT".equals(userRole.getRoleName())){
					loginForm.setNavigationUrl(ApplicationConstants.PROFILE);
				}else{
					loginForm.setNavigationUrl(ApplicationConstants.HOME_PAGE);
				}
				
				loginForm.setMessage("User Successfully Logged In");
				
			}
			
			LOG.log(Level.INFO,"END doLogin Method");
			
		}catch (EventException e) {
			LOG.log(Level.SEVERE,e.getMessage(),e);
		}
		return loginForm;
	}

	public User findUserByEmailId(String emailId){
		LOG.log(Level.INFO, "<!-----INSIDE findUserByEmailId() METHOD!!!!");
		return userProfileDAOApi.findUserByEmailId(emailId);
	}

	public User findUserByUserId(String userId){
		LOG.log(Level.INFO, "<!-----INSIDE findUserByUserId() METHOD!!!!");
		return userProfileDAOApi.findUserByUserId(userId);
	}

	public boolean isUserFirstTimeLoggedIn(String emailId){
		LOG.log(Level.INFO, "<!-----INSIDE isUserFirstTimeLoggedIn() METHOD!!!!");
		return userProfileDAOApi.isUserFirstTimeLoggedIn(emailId);
	}

	public User saveUserProfile(UserProfile profile){
		LOG.log(Level.INFO, "<!-----INSIDE saveUserProfile() METHOD!!!!");
		User entity = new User();
		entity.setUserId(profile.getUserId());
		entity.setDeleted(false);
		entity.setEmailId(profile.getEmail());
		entity.setFirstName(profile.getFirstName());
		entity.setFirstTimeLogin(true);
		entity.setLastName(profile.getLastName());
		entity.setPassword(profile.getPassword());
		return userProfileDAOApi.saveUserProfile(entity);
	}
	
}
