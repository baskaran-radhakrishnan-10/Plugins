$(document).ready(function(){
	console.log("manage reset password !!!");
	
	var url = window.location.href;
	
	if(url.indexOf("reset_password") > -1){
		
		$('#resetPasswordModel').trigger("click");
		
		$('#proceedButton').click(function(event){
			
			event.preventDefault();
			
			//console.log("Proceed Button Clicked!!!");
			
			var password1 = $('#password1').val();
			var password2 = $('#password2').val();
			
			//console.log("password1 :"+password1);
			//console.log("password2 :"+password2);
			
			//console.log(null != password1);
			//console.log(typeof(password1) == 'undefined');
			//console.log(password1 == "");
			
			if(null == password1 || typeof(password1) == 'undefined' || password1 == ""){
				console.log("password1 :failed")
				return false;
			}
			
			if(null == password2 || typeof(password2) == 'undefined' || password2 == ""){
				console.log("password2 :failed")
				return false;
			}
			
			if(password1 != password2){
				return false;
			}
			
			var data={};
			
			data["NEW_PASSWORD"] = password1;
			data["CONFIRM_NEW_PASSWORD"] = password2;
			
			$.ajax({
				type : "POST",
				contentType : "application/json",
				url : '/resetPasswordForFTL',
				data : JSON.stringify(data),
				success : function(result) {
					//console.log(result);
					if(result){
						window.location.href = "/";
					}
				},
				error : function(e) {
					console.log("ERROR: ", e);
				}
			});
			
		});
		
	}
	
});