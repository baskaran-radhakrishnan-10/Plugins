$(document).ready(function(){
	
	
	var url = window.location.href;
	
	if(url.indexOf("profile") > -1){
		
		var data={};
		$.ajax({
			type : "POST",
			contentType : "application/json",
			url : '/getProfileDetails',
			data : JSON.stringify(data),
			success : function(result) {
				console.log(result);
				//var result = JSON.parse(result);
				
				var user = result['USER'];
				var candidate = result['CANDIDATE'];
				var role = result['ROLE'];
				
				$('.loggedInUserName').text(user['firstName']+" "+user['lastName']);
				
				$('#roleName').text(role['roleName']);
				
				if(null != candidate){
					
					$('#collegeNameDiv p').text(candidate['collegeName']);
					
					$('#courseNameDiv p').text(candidate['course']);
					
					$('#deptDiv p').text(candidate['dept']);
					
					$('#gradeDiv p').text(candidate['aggregate']);
				
				}
				
				$('#candidateUserName').val(user['userId']);
				
				$('#candidateFirstName').val(user['firstName']);
				
				$('#candidateLastName').val(user['lastName']);
				
				$('#candidateEmail').val(user['emailId']);
				
				
				if(candidate['collegeName'].indexOf("$") > -1){
					eval($('#collegeNameDiv p').text());
				}
				
			},
			error : function(e) {
				console.log("ERROR: ", e);
			}
		});
		
	}
	
	
});