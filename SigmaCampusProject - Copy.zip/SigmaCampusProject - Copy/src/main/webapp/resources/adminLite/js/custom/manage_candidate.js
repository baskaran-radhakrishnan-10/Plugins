$(document).ready(function(){
	
	console.log("manage candidate!!!");
	
	var url = window.location.href;
	
	if(url.indexOf("create_candidate") > -1){
		
		var isFormValid = true ;
		
		
		
		$('#candidateEmail').blur(function(){
			
			var emailId = $(this).val();
			
			if(null != emailId && "undefined" !== typeof(emailId) && "" != emailId){
				
				$(this).parent().find("span").text("");
				$(this).parent().removeClass("has-error");
				isFormValid = true;
				
				var data = {};
				data['EMAIL'] = $('#candidateEmail').val().trim();
				
				$.ajax({
					type : "POST",
					contentType : "application/json",
					url : '/checkUserAlreadyExist',
					data : JSON.stringify(data),
					success : function(result) {
						console.log(result);
						if(result){
							$('#errorAlertDiv').show();
							$('#errorAlertDiv p').text("Given Email ID already available in the System!!!");
							isFormValid = false;
							setTimeout(function(){ $('#errorAlertDiv').hide(); }, 3000);
						}
					},
					error : function(e) {
						console.log("ERROR: ", e);
					}
				});
				
			}else{
				
				$(this).parent().find("span").text("Please enter Email ID value");
				$(this).parent().addClass("has-error");
				isFormValid = false;
				
			}
			
		});
		
		$('#candidateFirstName,#candidateUserName,#candidatePassword,#candidateLastName,#candidateCollegeName,#candidateRegNumber,#candidateYear,#candidateSemester,#candidateAggregate').blur(function(){
			var value = $(this).val();
			var label =  $(this).parent().find("label").text();
			console.log("Label :"+label);
			if(null == value || "undefined" == typeof(value) || "" == value){
				$(this).parent().find("span").text("Please enter "+label+" value");
				$(this).parent().addClass("has-error");
				isFormValid = false;
			}else{
				$(this).parent().find("span").text("");
				$(this).parent().removeClass("has-error");
				isFormValid = true;
			}
		});
		
		$('#createCandiateButton').click(function(event){
			
			$('#candidateEmail,#candidateFirstName,#candidateUserName,#candidatePassword,#candidateLastName,#candidateCollegeName,#candidateRegNumber,#candidateYear,#candidateSemester,#candidateAggregate').blur();
			
			if(!isFormValid){
				return false;
			}
			
			var data = {};
			
			data['EMAIL'] = $('#candidateEmail').val().trim();
			data['USER_NAME'] = $('#candidateUserName').val().trim();
			data['FIRST_NAME'] = $('#candidateFirstName').val().trim();
			data['LAST_NAME'] = $('#candidateLastName').val().trim();
			data['PASSWORD'] = $('#candidatePassword').val().trim();
			
			data['AGGREGATE'] = $('#candidateAggregate').val().trim();
			data['COLLEGE_NAME'] = $('#candidateCollegeName').val().trim();
			data['COURSE'] = $("#candidateCourseName option:selected" ).text();
			data['SEM'] = $('#candidateSemester').val().trim();
			data['DEPT'] = $("#candidateDepartmentName option:selected" ).text();
			data['YEAR'] = $('#candidateYear').val().trim();
			data['REG_NO'] = $('#candidateRegNumber').val().trim();
			
			$.ajax({
				type : "POST",
				contentType : "application/json",
				url : '/createCandidate',
				data : JSON.stringify(data),
				success : function(result) {
					console.log(result);
					$('#successAlertDiv').show();
					$('#successAlertDiv p').text("Candidate Profile Successfully Created.");
					setTimeout(function(){ $('#successAlertDiv').hide(); }, 3000);
				},
				error : function(e) {
					console.log("ERROR: ", e);
				}
			});
			
		});
		
		
	}
	
	
});