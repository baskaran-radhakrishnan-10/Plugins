package com.sigma.campus.web.security;

public class SecurityConstants {
	
	public static final String XSS_OBSERVABLE_NAME="XSS";
	
	public static final String XSS_ATTACK_REGEXP = "XSS_ATTACK_REGEXP";
	
	public static final String XSS_RESPONSE_FILTER_URL="XSS_RESPONSE_FILTER_URL";
	
	public static final String XSS_RESPONSE_VULNERABLE_KEY_WORDS="XSS_RESPONSE_VULNERABLE_KEY_WORDS";
	
	public static final String XSS_WHITELIST_PREFIX="XSS_WHITELIST_URL_";
	
	public static final String CUSTOM_XSS_CHECK_KEYS = "CUSTOM_XSS_CHECK_KEYS";

}
