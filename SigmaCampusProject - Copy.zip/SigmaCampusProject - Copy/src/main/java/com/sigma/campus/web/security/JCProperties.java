package com.sigma.campus.web.security;

public class JCProperties {

}
