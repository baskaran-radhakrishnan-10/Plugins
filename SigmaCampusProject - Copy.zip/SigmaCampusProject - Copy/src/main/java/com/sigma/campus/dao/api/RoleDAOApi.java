package com.sigma.campus.dao.api;

import java.util.List;

import com.sigma.campus.entity.Role;

public interface RoleDAOApi {
	
	public Role findRoleByRoleName(String roleName);
	
	public Role saveRole(Role role);
	
	public void saveRole(List<Role> roleList);

}
