package com.sigma.campus.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sigma.campus.entity.Resources;
import com.sigma.campus.entity.Role;
import com.sigma.campus.entity.Student;
import com.sigma.campus.entity.User;
import com.sigma.campus.entity.UserRole;

public class JsonHelper {
	
	private static final Logger LOG = Logger.getLogger(JsonHelper.class.getName());
	
	public static List<Role> getRoleObjectFromJsonFile(TypeReference<List<Role>> mapType,String filePath){
		List<Role> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		return returnObject;
	}
	
	public static List<Resources> getResourceObjectFromJsonFile(TypeReference<List<Resources>> mapType,String filePath){
		List<Resources> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		return returnObject;
	}
	
	public static List<UserRole> getUserRoleObjectFromJsonFile(TypeReference<List<UserRole>> mapType,String filePath){
		List<UserRole> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		return returnObject;
	}
	
	public static List<User> getUserObjectFromJsonFile(TypeReference<List<User>> mapType,String filePath){
		List<User> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		return returnObject;
	}
	
	public static List<Student> getStudentObjectFromJsonFile(TypeReference<List<Student>> mapType,String filePath){
		List<Student> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream is = TypeReference.class.getResourceAsStream(filePath);
		try {
			returnObject = mapper.readValue(is, mapType);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		return returnObject;
	}
	
	public static String getJsonStringFromJavaObject(Object object){
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String json=null;
		try {
			json = ow.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		return json;
	}
	
	public static Map<String,String> getMapObjectFromJsonString(String json){
		Map<String,String> returnObject = null;
		ObjectMapper mapper = new ObjectMapper();
		LOG.log(Level.INFO,json);
		try {
			returnObject = mapper.readValue(json, new TypeReference<Map<String,String>>() {});
		} catch (IOException e) {
			LOG.log(Level.SEVERE, e.getMessage(), e);
		}
		LOG.log(Level.INFO,returnObject.toString());
		return returnObject;
	}

}
