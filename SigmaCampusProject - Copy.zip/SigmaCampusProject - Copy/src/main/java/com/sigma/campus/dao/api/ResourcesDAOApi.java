package com.sigma.campus.dao.api;

import java.util.List;

import com.sigma.campus.entity.Resources;

public interface ResourcesDAOApi {
	
	public Resources findResourceByResourceID(String resourceId);
	
	public Resources saveResource(Resources resource);
	
	public void saveResource(List<Resources> resourcesList);

}
