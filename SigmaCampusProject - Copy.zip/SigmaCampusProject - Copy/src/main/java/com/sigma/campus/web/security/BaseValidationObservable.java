package com.sigma.campus.web.security;

import java.util.Map;
import java.util.Observable;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;

public abstract class BaseValidationObservable extends Observable implements IValidationObservable, Callable<BaseValidationObservable> {

	public abstract BaseValidationObservable call() throws Exception ;

	public abstract void setRequestForProcessing(HttpServletRequest request) ;
	
	public abstract void setDataObject(Map<String, String> dataObject);

	public abstract boolean isValidationConfiguredForUrl(HttpServletRequest request) throws ValidatorException;

	public abstract void setValidationHelper(ValidationHelper validationHelper); 

}
