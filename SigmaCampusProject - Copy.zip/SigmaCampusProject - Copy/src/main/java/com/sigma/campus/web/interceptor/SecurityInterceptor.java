package com.sigma.campus.web.interceptor;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.sigma.campus.constants.ApplicationConstants;
import com.sigma.campus.model.LoginModelAttribute;
import com.sigma.campus.web.security.ValidationObserver;

public class SecurityInterceptor extends HandlerInterceptorAdapter{
	
	private static final Logger LOG = Logger.getLogger(SecurityInterceptor.class.getName());
	
	private boolean ajax =false;

	private String uri=null;
	
	@Autowired
	ValidationObserver validationObserver;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		boolean isSecurityVulnerability = false;
		
		//isSecurityVulnerability = validationObserver.startScan(request);
		
		LOG.log(Level.INFO,"isSecurityVulnerability :"+isSecurityVulnerability);
		
		/*if(isSecurityVulnerability){
			response.sendRedirect(request.getContextPath()+"/403_error_page");
			return false;
		}*/
		
		//String requestBody= IOUtils.toString(request.getInputStream(), StandardCharsets.UTF_8.name());
		
		LOG.log(Level.INFO,"%%%%%%%%%%%%%%%%%%#####@@@@@@@@@@@@@@");
		
		//LOG.log(Level.INFO,requestBody);

		this.uri = request.getRequestURI();

		LOG.log(Level.INFO,"inside interceptor  and uri = "+this.uri);

		this.ajax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));

		LOG.log(Level.INFO,"ajax :"+ajax);

		HttpSession session=request.getSession();

		if(null == session.getAttribute(ApplicationConstants.BASE_URL)){

			String baseUrl = String.format("%s://%s:%d%s/",request.getScheme(),request.getServerName(), request.getServerPort(),request.getContextPath());

			session.setAttribute(ApplicationConstants.BASE_URL, baseUrl);

		}
		
		if((this.uri.indexOf("/403") > -1) && null != session.getAttribute("ERROR_OCCURED")){
			return true;
		}

		if(null == session.getAttribute(ApplicationConstants.IS_LOGGED_IN)){

			if(uri.indexOf("getSessionAttribute") != -1){
				return true;
			}

			request.setAttribute("loginModelAttribute", new LoginModelAttribute());
			
			if(ajax && (this.uri.indexOf("/doLogin") == -1)){
				session.setAttribute("REDIRECT_TO_LOGIN_PAGE", true);
				return false;
			}

			if(-1 != this.uri.indexOf("/doLogin")){
				if(request.getMethod().equalsIgnoreCase("GET")){
					request.setAttribute("loginModelAttribute", new LoginModelAttribute());
					response.sendRedirect(request.getContextPath()+"/login");
					return false;
				}
				return true;
			}

			if ((-1 == this.uri.indexOf("/login") ) && this.uri.indexOf(".js") == -1 && this.uri.indexOf(".css") == -1 && this.uri.indexOf(".png") == -1 && this.uri.indexOf(".gif") == -1 && this.uri.indexOf(".jpg") == -1  && this.uri.indexOf(".ttf") == -1) {
				LOG.log(Level.INFO,"<<<< -- There is no session Available -- >>>>");
				request.setAttribute("loginModelAttribute", new LoginModelAttribute());
				response.sendRedirect(request.getContextPath()+"/login");
				return false;
			}else{
				return true;
			}
		}

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception {
		//MultiReadHttpServletRequest multiRequest = new MultiReadHttpServletRequest((HttpServletRequest) request);
		LOG.log(Level.INFO,"Post handle :");
	}

	@Override
	public void afterCompletion(HttpServletRequest request,HttpServletResponse response, Object handler, Exception ex)throws Exception {
		LOG.log(Level.INFO,"After Complettion :");
	}
}
