package com.sigma.campus.spring.controller;

import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sigma.campus.constants.ApplicationConstants;
import com.sigma.campus.entity.Student;
import com.sigma.campus.entity.User;
import com.sigma.campus.model.LoginForm;
import com.sigma.campus.service.api.StudentServiceAPI;
import com.sigma.campus.service.api.UserLoginServiceAPI;
import com.sigma.campus.util.JsonHelper;
import com.sigma.campus.web.security.ValidationObserver;
import com.sigma.campus.web.security.ValidatorException;

@RestController
public class ApplicationRestController {
	
	private static final Logger LOG = Logger.getLogger(ApplicationRestController.class.getName());
	
	@Autowired
	private UserLoginServiceAPI userLoginService;
	
	@Autowired
	private StudentServiceAPI studentService;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	ValidationObserver validationObserver;
	
	@PostMapping(value = "/doLogin")
	public ResponseEntity<LoginForm> createCustomer(@RequestBody LoginForm loginForm) {
		boolean foundSecurityIssue = false;
		LOG.log(Level.SEVERE, "^^^^^^^^^^IS FOUND SECUIRTY ISSUE :"+foundSecurityIssue);
		try {
			foundSecurityIssue = validationObserver.startScan(request,JsonHelper.getMapObjectFromJsonString(JsonHelper.getJsonStringFromJavaObject(loginForm)));
		} catch (ValidatorException e1) {
			LOG.log(Level.SEVERE, e1.getMessage());
		}
		
		if(foundSecurityIssue){
			session.setAttribute("ERROR_OCCURED", foundSecurityIssue);
			loginForm.setErrorOccured(true);
			loginForm.setMessage("403 FORBIDDEN ERROR OCCURRED");
			loginForm.setNavigationUrl("403");
			return new ResponseEntity<LoginForm>(loginForm, HttpStatus.OK);
		}
		
		session.removeAttribute("ERROR_OCCURED");
		
		LOG.log(Level.SEVERE, "^^^^^^^^^^IS FOUND SECUIRTY ISSUE :"+foundSecurityIssue);
		
		String userId = loginForm.getUserId();
		String password = loginForm.getPassword();
		
		if(null == userId || userId.isEmpty()){
			loginForm.setErrorOccured(true);
			loginForm.setMessage("Enter valid user id");
			loginForm.setNavigationUrl(ApplicationConstants.LOGIN_PAGE);
		}

		if(null == password || password.isEmpty()){
			loginForm.setErrorOccured(true);
			loginForm.setMessage("Enter valid password");
			loginForm.setNavigationUrl(ApplicationConstants.LOGIN_PAGE);
		}
		
		try {
			loginForm=userLoginService.doLogin(loginForm);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<LoginForm>(loginForm, HttpStatus.OK);
	}
	
	@PostMapping(value="/getAllStudents")
	public ResponseEntity<List<Student>> getAllStudents(@RequestBody Map<String,Object> data) {
		return new ResponseEntity<List<Student>>(studentService.getAllStudents(), HttpStatus.OK);
	}
	
	@PostMapping(value="/createCandidate")
	public ResponseEntity<Boolean> createCandidate(@RequestBody Map<String,String> data) {
		LOG.log(Level.INFO, "createCandidate()");
		boolean foundSecurityIssue = false;
		try {
			foundSecurityIssue = validationObserver.startScan(request,data);
		} catch (ValidatorException e1) {
			e1.printStackTrace();
		}
		return new ResponseEntity<Boolean>(studentService.saveCandidate(data), HttpStatus.OK);
	}
	
	@PostMapping(value="/checkUserAlreadyExist")
	public ResponseEntity<Boolean> checkUserAlreadyExist(@RequestBody Map<String,String> data) {
		LOG.log(Level.INFO, "createCandidate()");
		boolean foundSecurityIssue = false;
		try {
			foundSecurityIssue = validationObserver.startScan(request,data);
		} catch (ValidatorException e1) {
			e1.printStackTrace();
		}
		User user = userLoginService.findUserByEmailId(data.get("EMAIL"));
		
		if(null != user){
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		}else{
			return new ResponseEntity<Boolean>(false, HttpStatus.OK);
		}
	}
	
	@PostMapping(value="/getProfileDetails")
	public ResponseEntity<Map<String,Object>> getProfileDetails(@RequestBody Map<String,String> data) {
		LOG.log(Level.INFO, "getProfileDetails()");
		try {
			validationObserver.startScan(request,data);
		} catch (ValidatorException e1) {
			e1.printStackTrace();
		}
		return new ResponseEntity<>(studentService.getProfileInfo(String.valueOf(session.getAttribute(ApplicationConstants.USER_ID))), HttpStatus.OK);
	}
	
	@PostMapping(value="/resetPasswordForFTL")
	public ResponseEntity<Boolean> resetPasswordForFirstTimeLogin(@RequestBody Map<String,String> data) {
		LOG.log(Level.INFO, "getProfileDetails()");
		
		String password = null;
		
		try {
			validationObserver.startScan(request,data);
			
			String newPassword = data.get("NEW_PASSWORD");
			String confirmNewPassword = data.get("CONFIRM_NEW_PASSWORD");
			
			if(null != newPassword && newPassword.equals(confirmNewPassword)){
				password = newPassword;
			}
			
		} catch (ValidatorException e1) {
			e1.printStackTrace();
		}
		return new ResponseEntity<>(userLoginService.resetPassword(String.valueOf(session.getAttribute(ApplicationConstants.USER_ID)), password), HttpStatus.OK);
	}
	
}
