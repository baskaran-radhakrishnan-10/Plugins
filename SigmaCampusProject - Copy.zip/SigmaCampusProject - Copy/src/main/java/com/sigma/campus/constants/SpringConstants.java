package com.sigma.campus.constants;

public class SpringConstants {
	
	public static final String USER_PROFILE_DAO_API = "userProfileDAOApi";
	
	public static final String ROLE_DAO_API = "roleDAOApi";
	
	public static final String RESOURCES_DAO_API = "resourcesDAOApi";
	
	public static final String USER_ROLE_DAO_API = "userRoleDAOApi";
	
	public static final String USER_LOGIN_SERVICE = "userLoginService";
	
	public static final String STUDENT_SERVICE = "studentService";
	
	public static final String STUDENT_DAO_API = "studentDAOApi";
	
}
