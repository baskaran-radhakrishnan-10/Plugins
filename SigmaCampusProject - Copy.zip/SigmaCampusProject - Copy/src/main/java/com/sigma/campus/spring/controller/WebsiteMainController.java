package com.sigma.campus.spring.controller;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.cache.CacheException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sigma.campus.constants.ApplicationConstants;

@Controller
public class WebsiteMainController {
	
	private static final Logger LOG = Logger.getLogger(WebsiteMainController.class.getName());
	
	@Autowired
	private HttpSession session;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String rootUrl(HttpServletRequest request,HttpServletResponse response){
		LOG.log(Level.INFO, "Inside Root URL Mapper");
		
		String roleName = (String) session.getAttribute(ApplicationConstants.ROLE_ID);
		
		if(null !=  roleName){
			if("STUDENT".equals(roleName)){
				return ApplicationConstants.REDIRECT_PROFILE_PAGE;
			}else{
				return ApplicationConstants.REDIRECT_HOME_PAGE;
			}
		}
		
		return ApplicationConstants.REDIRECT_HOME_PAGE;
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String showDashboardPage(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.HOME_PAGE;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage(HttpServletRequest request,HttpServletResponse response){
		return ApplicationConstants.LOGIN_PAGE;
	}
	
	@RequestMapping(value = "/signout")
	public String doLogout(HttpServletRequest request) throws CacheException{
		request.getSession().invalidate();
		return ApplicationConstants.REDIRECT_LOGIN_PAGE;
	}
	
	@RequestMapping(value = "/profile")
	public String showProfilePage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.PROFILE;
	}
	
	@RequestMapping(value = "/manage")
	public String decideMangePage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.PROFILE;
	}
	
	@RequestMapping(value = "/manageStudents")
	public String showManageStudentsPage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.MANAGE_STUDENTS;
	}
	
	@RequestMapping(value = "/create_candidate")
	public String showCreateCandiatePage(HttpServletRequest request) throws CacheException{
		LOG.log(Level.INFO, "showCreateCandiatePage");
		LOG.log(Level.INFO, "request",request.getParameter("cookie"));
		return ApplicationConstants.CREATE_CANDIDATE;
	}
	
	@RequestMapping(value = "/reset_password")
	public String showResetPasswordPage(HttpServletRequest request) throws CacheException{
		LOG.log(Level.INFO, "showResetPasswordPage @@@@@@@@@@@@@@@@@@@@$$$$$$$$");
		return ApplicationConstants.RESET_PASSWORD;
	}
	
	@RequestMapping(value = "/manageColleges")
	public String showManageCollegesPage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.MANAGE_COLLEGES;
	}
	
	@RequestMapping(value = "/403")
	public String show403ErrorPage(HttpServletRequest request) throws CacheException{
		return ApplicationConstants.ERROR_PAGE_403;
	}
	
}
