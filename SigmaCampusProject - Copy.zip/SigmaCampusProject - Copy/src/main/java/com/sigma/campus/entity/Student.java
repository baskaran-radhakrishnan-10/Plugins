package com.sigma.campus.entity;

import java.io.Serializable;

import com.google.appengine.api.datastore.Key;

public class Student implements Serializable{
	
	private static final long serialVersionUID = -8672439224248419144L;
	
	public static final String ID="id";
	
	public static final String NAME="name";

	public static final String COLLEGE_NAME="collegeName";

	public static final String COURSE="course";

	public static final String YEAR="year";
	
	public static final String DEPT="dept";

	public static final String SEMESTER="semester";

	public static final String AGGREGATE = "aggregate";

	public static final String ENTITY_NAME="Student";
	
	private Key key;
	
	private long id;
	
	private String name;
	
	private String collegeName;
	
	private String course;
	
	private String year;
	
	private String dept;
	
	private String semester;
	
	private double aggregate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public double getAggregate() {
		return aggregate;
	}

	public void setAggregate(double aggregate) {
		this.aggregate = aggregate;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}
	
}
