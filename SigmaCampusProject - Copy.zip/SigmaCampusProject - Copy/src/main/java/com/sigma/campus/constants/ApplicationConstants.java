package com.sigma.campus.constants;

public class ApplicationConstants {

	public static final String IS_LOGGED_IN="IS_LOGGED_IN";

	public static final String BASE_URL = "baseUrl";

	public static final String LOGIN_PAGE="login";

	public static final String RESET_PASSWORD_PAGE="reset_passwprd_page";

	public static final String REDIRECT_LOGIN_PAGE="redirect:/login";
	
	public static final String REDIRECT_PROFILE_PAGE="redirect:/profile";

	public static final String HOME_PAGE="dashboard";

	public static final String REDIRECT_HOME_PAGE="redirect:/dashboard";

	public static final String USER_OBJ="USER_OBJ";

	public static final String USER_ID="USER_ID";

	public static final String USER_NAME="USER_NAME";

	public static final String ROLE_ID = "roleId";

	public static final String FIRST_LOGIN = "FIRST_LOGIN";
	
	public static final String PROFILE = "profile";
	
	public static final String MANAGE_STUDENTS = "manage_students";
	
	public static final String MANAGE_COLLEGES = "manage_colleges";
	
	public static final String CREATE_CANDIDATE = "create_candidate";
	
	public static final String RESET_PASSWORD = "reset_password";
	
	public static final String ERROR_PAGE_403="403_error_page";

}
