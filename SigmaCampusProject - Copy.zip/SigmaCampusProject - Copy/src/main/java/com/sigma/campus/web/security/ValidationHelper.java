package com.sigma.campus.web.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.owasp.validator.html.Policy;
import org.owasp.validator.html.PolicyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;

@Component("validationHelper")
public class ValidationHelper {

	private static final Logger LOG = Logger.getLogger(ValidationHelper.class.getName());
	
	/**
	 * This variable stores the values of custom xss request keywords values in array.
	 */
	public String[] customXSSKEYS=null;

	/**
	 * This variable stores the values of vulnerable xss response keywords values in array.
	 */
	public String[] xssResponseKeyWordsArray=null;

	/**
	 * This variable stores the values of vulnerable xss requesr keywords in the form regx pattern list.
	 */
	public List<String> xssDangerousRegExp=null;

	/**
	 * This variable stores the values of vulnerable xss response protected  urls list
	 */
	public List<String> xssResponseFilterUrlList = null;


	/**
	 * This variable stores the values of Policy Instance
	 */
	public Policy policy=null;

	public File policyFile=null;
	
	public static boolean isXssProtectionRequired = false;


	/**
	 * This variable holds the broken autherization white listed urls and fields file name.
	 */
	private List<String> observablesRunList = null;

	public HashMap<String,String> xssWhitelistedUrls = new HashMap<String,String>();

	
	public ValidationHelper(){
		
		Properties xssProperties=getPropertiesFromFile(ValidationHelper.class.getResourceAsStream("/validation/security_framework.properties"));
		
		final InputStream xmlInputStream = ValidationHelper.class.getResourceAsStream("/validation/antisamy-1.4.1.xml");
		
		//LOG.log(Level.INFO, "xssPropertiesFile: "+xssPropertiesFile);
		//LOG.log(Level.INFO, "ruleFilePath: "+ruleFilePath);
		//LOG.log(Level.INFO, "antiSamyResource: "+is.getFilename());

		loadXssPropertyFile("/validation/xss.properties");
		
		try {
			policy=Policy.getInstance(xmlInputStream);
		} catch (PolicyException e) {
			e.printStackTrace();
		}
		
		//policyFile=new File(policy.getInstance());
		
		observablesRunList = new ArrayList<String>();
		
		if(null != xssProperties.get("XSS_PROTECTION_REQUIRED")){
			isXssProtectionRequired = Boolean.valueOf(xssProperties.get("XSS_PROTECTION_REQUIRED").toString());
		}
		
		if(isXssProtectionRequired){
			observablesRunList.add(SecurityConstants.XSS_OBSERVABLE_NAME);
		}
		
		LOG.log(Level.INFO, "&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		LOG.log(Level.INFO, observablesRunList.toString());

	}

	public List<String> getObservablesRunList() {
		return observablesRunList;
	}

	public void setObservablesRunList(List<String> observablesRunList) {
		this.observablesRunList = observablesRunList;
	}

	private void loadXssPropertyFile(String propertiesFileName){

		Properties xssProperties=getPropertiesFromFile(ValidationHelper.class.getResourceAsStream(propertiesFileName));

		if(xssProperties != null){

			String key="";

			Set<Object> propertyKeySet = xssProperties.keySet();

			Iterator<Object> iterator = propertyKeySet.iterator();

			Set<String> xssResponseFilterUrlSet=new HashSet<String>();

			customXSSKEYS=null;
			xssDangerousRegExp=null;
			xssResponseKeyWordsArray=null;
			xssWhitelistedUrls = new HashMap<String,String>();

			while (iterator.hasNext()) {

				key = (String) iterator.next();

				if(key.startsWith(SecurityConstants.XSS_WHITELIST_PREFIX)) {
					xssWhitelistedUrls.put((String) xssProperties.get(key), (String) xssProperties.get(key));
				}

				if (key.startsWith(SecurityConstants.XSS_RESPONSE_FILTER_URL)) {

					xssResponseFilterUrlSet.add((String) xssProperties.get(key));

				}

			}

			if(xssProperties.get(SecurityConstants.CUSTOM_XSS_CHECK_KEYS)!= null){

				customXSSKEYS=null;

				customXSSKEYS=((String)xssProperties.get(SecurityConstants.CUSTOM_XSS_CHECK_KEYS)).split(",");

			}

			if (xssProperties.getProperty(SecurityConstants.XSS_ATTACK_REGEXP) != null) {

				xssDangerousRegExp=null;

				xssDangerousRegExp = Arrays.asList(xssProperties.getProperty(SecurityConstants.XSS_ATTACK_REGEXP).split(","));

			}

			if(xssProperties.getProperty(SecurityConstants.XSS_RESPONSE_VULNERABLE_KEY_WORDS) != null){

				xssResponseKeyWordsArray=null;

				xssResponseKeyWordsArray=((String)xssProperties.get(SecurityConstants.XSS_RESPONSE_VULNERABLE_KEY_WORDS)).split(",");

			}


			if(xssResponseFilterUrlSet != null ){

				xssResponseFilterUrlList=new ArrayList<String>(xssResponseFilterUrlSet);

			}
			
			//LOG.log(Level.INFO, customXSSKEYS.toString());
			
			//LOG.log(Level.INFO, xssDangerousRegExp.toString());
			
			//LOG.log(Level.INFO, xssResponseKeyWordsArray.toString());

		}

	}

	private  Properties getPropertiesFromFile(InputStream inStream){

		/*if (LOG.isDebugEnabled()) {
			LOG.debug("Loading Property File  Starts" + propertiesFileName);
		}*/

		FileInputStream fis = null;

		Properties properties =null;

		try {

			//File propsFile = new File(propertiesFileName);
			
			properties = new Properties();
			
			properties.load(inStream);

			/*if(propsFile.exists()){

				properties = new Properties();

				fis = new FileInputStream(propsFile);

				

			}*/

		} catch (IOException e) {

			//LOG.error("Failed to Load  properties", e);

		} catch (IllegalArgumentException e) {

			//LOG.error("Failed to Load  properties", e);

		} catch (Exception e) {

			//LOG.error("Failed to Load  properties", e);

		} finally {

			if (fis != null) {

				try {

					fis.close();

				} catch (IOException e) {

					//LOG.error("Failed close properties file", e);

				}

			}

		}

		return properties;

	}
	
	public void loadAntisamyPolicyFile(File policyFile) throws ValidatorException{
		
		/*if(isFileReloadingRequired(policyFile.lastModified(), propertyFileLastLoadTimeMap.get("policy"))){*/
			
			try {
				
				policy=Policy.getInstance(ValidationHelper.class.getResourceAsStream("/validation/antisamy-1.4.1.xml"));
				
			} catch (Exception e) {
				
				LOG.log(Level.SEVERE, "ERROR :"+e.getMessage());
				
				//throw new ValidatorException(ValidatorFaultCode.LOAD_PROPERTIES_FAILED,e);
				
			}
			
			//propertyFileLastLoadTimeMap.put("policy", new Timestamp(Calendar.getInstance().getTime().getTime()));
			
		/*}*/
		
	}

}
