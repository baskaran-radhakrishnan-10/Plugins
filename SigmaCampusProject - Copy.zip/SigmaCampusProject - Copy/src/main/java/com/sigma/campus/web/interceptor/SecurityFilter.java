package com.sigma.campus.web.interceptor;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;

public class SecurityFilter implements Filter {
	
	private static final Logger LOG = Logger.getLogger(SecurityFilter.class.getName());

	@Override
	public void destroy() {
		LOG.log(Level.INFO,"SecurityFilter destroy method");
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		LOG.log(Level.INFO,"SecurityFilter init method");
	}

	@Override
	public void doFilter(ServletRequest request,ServletResponse response, FilterChain chain)throws IOException, ServletException {
		LOG.log(Level.INFO,"SecurityFilter doFilter method");
		try {
			
			//String json = "";
			
			MultiReadHttpServletRequest multiRequest = new MultiReadHttpServletRequest((HttpServletRequest) request);
			
			LOG.log(Level.INFO,"Body : "+multiRequest.getBody());
			
			/*BufferedReader br = multiRequest.getReader();
	        
	        if(br != null){
	            json = br.readLine();
	        }
	 
	        // 2. initiate jackson mapper
	        ObjectMapper mapper = new ObjectMapper();
	 
	        // 3. Convert received JSON to Article
	        Map<String,Object> article = mapper.readValue(json, Map.class);
	        
	        if(null != article){
	        	for(String key : article.keySet()){
	        		LOG.log(Level.INFO,"key : "+key);
	        		LOG.log(Level.INFO,"value : "+article.get(key));
	        	}
	        }*/
			
			chain.doFilter(request, response);
			
		} catch (Exception ex) {
			//request.setAttribute("errorMessage", ex);
			//request.getRequestDispatcher("/WEB-INF/views/jsp/error.jsp").forward(request, response);
		}
	}

}
