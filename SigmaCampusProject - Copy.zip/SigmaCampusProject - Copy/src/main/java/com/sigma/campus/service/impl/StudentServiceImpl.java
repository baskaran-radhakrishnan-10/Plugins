package com.sigma.campus.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.sigma.campus.constants.SpringConstants;
import com.sigma.campus.dao.api.StudentDAOApi;
import com.sigma.campus.dao.api.UserRoleDAOApi;
import com.sigma.campus.entity.Student;
import com.sigma.campus.entity.User;
import com.sigma.campus.entity.UserRole;
import com.sigma.campus.model.UserProfile;
import com.sigma.campus.service.api.StudentServiceAPI;
import com.sigma.campus.service.api.UserLoginServiceAPI;
import com.sigma.campus.util.JsonHelper;

@Component(SpringConstants.STUDENT_SERVICE)
public class StudentServiceImpl implements StudentServiceAPI{

	private static final Logger LOG = Logger.getLogger(StudentServiceImpl.class.getName());

	@Autowired
	private StudentDAOApi studentDAOApi;
	
	@Autowired
	private UserLoginServiceAPI userLoginService;
	
	@Autowired
	private UserRoleDAOApi userRoleDAOApi;

	@PostConstruct
	public void init(){
		LOG.log(Level.INFO, "Inside");
		List<Student> studentList = (List<Student>) JsonHelper.getStudentObjectFromJsonFile(new TypeReference<List<Student>>() {}, "/json/Students.json");
		studentDAOApi.saveStudentProfile(studentList);
	}
	
	public List<Student> getAllStudents(){
		return studentDAOApi.getAllStudents();
	}
	
	
	public boolean  saveCandidate(Map<String,String> requestObject){
		
		LOG.log(Level.INFO, "saveCandidate()");
		LOG.log(Level.INFO, "Request Object",requestObject);
		
		try{
			UserProfile user = new UserProfile();
			user.setEmail(requestObject.get("EMAIL"));
			user.setFirstName(requestObject.get("FIRST_NAME"));
			user.setLastName(requestObject.get("LAST_NAME"));
			user.setPassword(requestObject.get("PASSWORD"));
			user.setUserId(requestObject.get("USER_NAME"));
			user.setConfirmPassword(requestObject.get("PASSWORD"));
			
			UserRole userRole = new UserRole();
			userRole.setRoleName("STUDENT");
			userRole.setUserId(requestObject.get("USER_NAME"));
			
			Student student=new Student(); 
			student.setAggregate(Double.valueOf(requestObject.get("AGGREGATE")));
			student.setCollegeName(requestObject.get("COLLEGE_NAME"));
			student.setCourse(requestObject.get("COURSE"));
			student.setDept(requestObject.get("DEPT"));
			student.setId(Long.valueOf(requestObject.get("REG_NO")));
			student.setName(requestObject.get("USER_NAME"));
			student.setSemester(requestObject.get("SEM"));
			student.setYear(requestObject.get("YEAR"));
			
			userLoginService.saveUserProfile(user);
			userRoleDAOApi.saveUserRole(userRole);
			studentDAOApi.saveStudent(student);
			
		}catch(Exception e){
			LOG.log(Level.SEVERE, "Error Occurred -- >",e.getMessage());
			requestObject.put("ERROR", e.getMessage());
			return false;
		}
		
		LOG.log(Level.INFO, "Candidate Creation DOne!!!",requestObject.toString());
		
		return true;
	}
	
	public Map<String,Object> getProfileInfo(String userName){
		LOG.log(Level.INFO, "getProfileInfo()");
		LOG.log(Level.INFO, "User Name () :"+userName );
		Map<String,Object> resultMap =new HashMap<>();
		try{
			User user = userLoginService.findUserByUserId(userName);
			UserRole userRole = userRoleDAOApi.findByUserId(userName);
			Student student = studentDAOApi.findStudentByUserName(userName);
			
			resultMap.put("USER", user);
			resultMap.put("ROLE", userRole);
			resultMap.put("CANDIDATE", student);
			
		}catch(Exception e){
			LOG.log(Level.SEVERE, "Error Occurred -- >"+e.getMessage());
		}
		return resultMap;
	}

}
